import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Plus,
  Users,
  TriangleAlert,
  ListChecks,
  Bell,
  Clock3,
  UserCog,
  FileAudio,
  ChevronRight,
  CalendarClock,
} from 'lucide-react';
import { useAuth } from '../lib/AuthContext.jsx';
import { handoverApi, residentApi, shiftApi, notificationApi, ApiError } from '../lib/api.js';
import { useAutoClockOut } from '../lib/useAutoClockOut.js';
import { UrgencyBadge } from '../components/Badge.jsx';
import { EmptyState, ErrorState } from '../components/States.jsx';
import { formatRelative, formatDateTime, firstName, truncate } from '../lib/format.js';
import NewHandoverModal from '../components/NewHandoverModal.jsx';
import HandoverDetailModal from '../components/HandoverDetailModal.jsx';

export default function DashboardPage() {
  const { user, isManager } = useAuth();
  const navigate = useNavigate();

  const [handovers, setHandovers] = useState(null);
  // Handovers on record: the API returns { results, total } — `total` is the
  // true count of matching notes, independent of how many rows this page
  // actually fetched (capped at `limit`). Stat cards must read `total`, not
  // the length of the fetched-and-capped `results` array.
  const [handoverTotal, setHandoverTotal] = useState(null);
  const [residents, setResidents] = useState([]);
  const [shifts, setShifts] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [error, setError] = useState(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [openNote, setOpenNote] = useState(null);

  const reloadShifts = useCallback(() => {
    shiftApi.list().then(setShifts).catch(() => { });
  }, []);

  const load = useCallback(async () => {
    setError(null);
    try {
      const [handoverData, residentData] = await Promise.all([handoverApi.list({ limit: 30 }), residentApi.list(false)]);
      // API returns a paginated object { results, total } — unwrap it here.
      // The `?? handoverData` fallback keeps this working if the endpoint
      // ever returns a bare array instead.
      setHandovers(handoverData?.results ?? handoverData ?? []);
      setHandoverTotal(
        typeof handoverData?.total === 'number'
          ? handoverData.total
          : Array.isArray(handoverData)
            ? handoverData.length
            : null
      );
      setResidents(residentData);
      shiftApi.list().then(setShifts).catch(() => { });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your dashboard.');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function loadDashboard() {
      await load();
      if (cancelled) return;
      if (isManager) {
        notificationApi.list(50).then((n) => !cancelled && setNotifications(n)).catch(() => { });
      }
    }
    loadDashboard();
    return () => {
      cancelled = true;
    };
  }, [isManager, load]);

  const residentMap = useMemo(() => Object.fromEntries(residents.map((r) => [r.id, r.name])), [residents]);

  // Defensive guards: never assume `handovers` is an array, even after the
  // fetch-side fix above, in case the shape changes again upstream.
  const safeHandovers = Array.isArray(handovers) ? handovers : [];

  const recentHandovers = safeHandovers.slice(0, 6);
  const urgentHandovers = safeHandovers.filter((n) => n.urgency_flag === 'high' || n.urgency_flag === 'urgent').slice(0, 5);
  const allFollowUps = safeHandovers
    .filter((n) => n.status === 'complete' && n.summary_json?.follow_up_actions?.length)
    .flatMap((n) => n.summary_json.follow_up_actions.map((action) => ({ action, note: n })))
    // A follow-up only leaves this list once someone actually marks it done —
    // not the moment the AI summary happens to mention it.
    .filter(({ action, note }) => !(note.resolved_follow_ups || []).includes(action));
  // The stat card and "Mark done" logic need the TRUE count; only the
  // on-screen list of rows should be capped to 6 for display purposes.
  const followUps = allFollowUps.slice(0, 6);

  async function resolveFollowUp(f) {
    // Optimistic: flip it off the list immediately, reconcile with the
    // server response (which becomes the new source of truth) after.
    setHandovers((prev) =>
      (prev || []).map((n) =>
        n.id === f.note.id ? { ...n, resolved_follow_ups: [...(n.resolved_follow_ups || []), f.action] } : n
      )
    );
    try {
      const updated = await handoverApi.setFollowUpResolved(f.note.id, f.action, true);
      setHandovers((prev) => (prev || []).map((n) => (n.id === updated.id ? updated : n)));
    } catch {
      // Revert on failure.
      setHandovers((prev) =>
        (prev || []).map((n) =>
          n.id === f.note.id
            ? { ...n, resolved_follow_ups: (n.resolved_follow_ups || []).filter((a) => a !== f.action) }
            : n
        )
      );
    }
  }

  const currentShift = shifts.find((s) => {
    const now = Date.now();
    const start = new Date(s.start_time).getTime();
    const end = s.end_time ? new Date(s.end_time).getTime() : null;
    return start <= now && (!end || end > now);
  });
  const nextShift = shifts
    .filter((s) => new Date(s.start_time).getTime() > Date.now())
    .sort((a, b) => new Date(a.start_time) - new Date(b.start_time))[0];

  useAutoClockOut(!isManager ? currentShift : null, null, reloadShifts);

  const unreadAlerts = notifications.filter((n) => !n.is_read).length;
  const activeResidents = residents.filter((r) => r.status === 'active');

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Welcome back{user ? `, ${firstName(user)}` : ''}</h1>
          <p>{isManager ? "Here's what's happening across your care home today." : "Here's your shift overview."}</p>
        </div>
      </div>

      <div className="stat-row">
        {isManager ? (
          <>
            <StatCard icon={Users} label="Active residents" value={activeResidents.length} tone="default" />
            <StatCard icon={TriangleAlert} label="Urgent handovers (recent)" value={urgentHandovers.length} tone="high" />
            <StatCard icon={Bell} label="Unread alerts" value={unreadAlerts} tone="medium" />
            <StatCard icon={FileAudio} label="Handovers on record" value={handoverTotal !== null ? handoverTotal : '—'} tone="info" />
          </>
        ) : (
          <>
            <StatCard
              icon={Clock3}
              label="Current shift"
              value={currentShift ? 'On shift' : 'Off shift'}
              tone={currentShift ? 'default' : 'info'}
            />
            <StatCard icon={Users} label="Active residents" value={activeResidents.length} tone="default" />
            <StatCard icon={FileAudio} label="Your recent handovers" value={handoverTotal !== null ? handoverTotal : '—'} tone="info" />
            <StatCard icon={ListChecks} label="Open follow-ups" value={allFollowUps.length} tone="medium" />
          </>
        )}
      </div>

      <div className="dash-grid">
        <div>
          <div className="panel">
            <div className="panel-header">
              <h3>Recent handovers</h3>
              <button className="panel-link" onClick={() => navigate('/handovers', {})}>
                View all
              </button>
            </div>
            <div className="panel-body">
              {handovers === null && !error && <SkeletonRows />}
              {error && <ErrorState message={error} onRetry={load} />}
              {handovers !== null && recentHandovers.length === 0 && (
                <EmptyState icon={FileAudio} title="No handovers yet" message="Recent handover notes will show up here." />
              )}
              {recentHandovers.map((n) => (
                <div className="list-row" key={n.id} onClick={() => setOpenNote(n)} role="button" tabIndex={0}>
                  <span className="list-row-icon">
                    <FileAudio />
                  </span>
                  <span className="list-row-body">
                    <span className="list-row-title">{residentMap[n.resident_id] || `Resident #${n.resident_id}`}</span>
                    <span className="list-row-meta">
                      {formatRelative(n.created_at)}
                      {isManager && (n.submitted_by?.name?.trim() || n.submitted_by?.username) && (
                        <> &middot; {n.submitted_by.name?.trim() || n.submitted_by.username}</>
                      )}
                    </span>
                  </span>
                  <span className="list-row-side">
                    {n.status === 'complete' ? <UrgencyBadge urgency={n.urgency_flag} /> : <span className="badge badge-info">{n.status}</span>}
                    <ChevronRight size={15} color="var(--text-tertiary)" />
                  </span>
                </div>
              ))}
            </div>
          </div>

          {isManager && (
            <div className="panel">
              <div className="panel-header">
                <h3>Residents needing attention</h3>
                <button className="panel-link" onClick={() => navigate('/residents', {})}>
                  View residents
                </button>
              </div>
              <div className="panel-body">
                {urgentHandovers.length === 0 && (
                  <EmptyState icon={TriangleAlert} title="Nothing urgent" message="High and urgent handovers will surface here." />
                )}
                {urgentHandovers.map((n) => (
                  <div className="list-row" key={n.id} onClick={() => setOpenNote(n)} role="button" tabIndex={0}>
                    <span className="list-row-icon list-row-icon-danger">
                      <TriangleAlert />
                    </span>
                    <span className="list-row-body">
                      <span className="list-row-title">{residentMap[n.resident_id] || `Resident #${n.resident_id}`}</span>
                      <span className="list-row-meta">{truncate(n.summary_json?.summary, 80)}</span>
                    </span>
                    <span className="list-row-side">
                      <UrgencyBadge urgency={n.urgency_flag} />
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {!isManager && (
            <div className="panel">
              <div className="panel-header">
                <h3>Outstanding follow-ups</h3>
              </div>
              <div className="panel-body">
                {followUps.length === 0 && <EmptyState icon={ListChecks} title="All caught up" message="Follow-up actions from your handovers will appear here." />}
                {followUps.map((f, i) => (
                  <div className="list-row" key={i}>
                    <span className="list-row-icon" onClick={() => setOpenNote(f.note)} role="button" tabIndex={0}>
                      <ListChecks />
                    </span>
                    <span className="list-row-body" onClick={() => setOpenNote(f.note)} role="button" tabIndex={0}>
                      <span className="list-row-title">{f.action}</span>
                      <span className="list-row-meta">
                        {residentMap[f.note.resident_id] || `Resident #${f.note.resident_id}`} &middot; {formatRelative(f.note.created_at)}
                      </span>
                    </span>
                    <button
                      type="button"
                      className="btn btn-secondary btn-sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        resolveFollowUp(f);
                      }}
                    >
                      Mark done
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div>
          <div className="panel">
            <div className="panel-header">
              <h3>Quick actions</h3>
            </div>
            <div className="panel-body panel-body-md">
              <div className="quick-actions">
                {!isManager && (
                  <button className="quick-action-btn" onClick={() => setShowNewModal(true)}>
                    <Plus />
                    <span className="quick-action-text">
                      <strong>New handover</strong>
                      <span>Record or upload audio</span>
                    </span>
                  </button>
                )}
                {isManager && (
                  <button className="quick-action-btn" onClick={() => navigate('/residents', {})}>
                    <Users />
                    <span className="quick-action-text">
                      <strong>Add resident</strong>
                      <span>Register a new resident</span>
                    </span>
                  </button>
                )}
                {isManager && (
                  <button className="quick-action-btn" onClick={() => navigate('/team', {})}>
                    <UserCog />
                    <span className="quick-action-text">
                      <strong>Manage team</strong>
                      <span>Add or update staff</span>
                    </span>
                  </button>
                )}
                {!isManager && (
                  <button className="quick-action-btn" onClick={() => navigate('/shifts', {})}>
                    <Clock3 />
                    <span className="quick-action-text">
                      <strong>Log a shift</strong>
                      <span>Record your working hours</span>
                    </span>
                  </button>
                )}
                <button className="quick-action-btn" onClick={() => navigate('/residents', {})}>
                  <Users />
                  <span className="quick-action-text">
                    <strong>View residents</strong>
                    <span>{activeResidents.length} active</span>
                  </span>
                </button>
                {isManager && (
                  <button className="quick-action-btn" onClick={() => navigate('/notifications', {})}>
                    <Bell />
                    <span className="quick-action-text">
                      <strong>Review alerts</strong>
                      <span>{unreadAlerts} unread</span>
                    </span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {!isManager && (
            <div className="panel">
              <div className="panel-header">
                <h3>Your shift</h3>
              </div>
              <div className="panel-body panel-body-lg">
                {currentShift ? (
                  <div className="shift-status">
                    <span className="badge badge-active badge-fit">
                      Ongoing
                    </span>
                    <div className="shift-status-meta">
                      Started {formatDateTime(currentShift.start_time)}
                    </div>
                  </div>
                ) : nextShift ? (
                  <div className="shift-status">
                    <span className="shift-status-next">
                      <CalendarClock size={15} /> Next shift {formatDateTime(nextShift.start_time)}
                    </span>
                  </div>
                ) : (
                  <p className="shift-status-empty">No upcoming shifts logged.</p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {showNewModal && (
        <NewHandoverModal
          residents={activeResidents}
          shifts={shifts}
          onClose={() => setShowNewModal(false)}
          onSubmitted={() => {
            setShowNewModal(false);
            load();
          }}
        />
      )}
      {openNote && <HandoverDetailModal note={openNote} residentName={residentMap[openNote.resident_id]} canDelete={false} onClose={() => setOpenNote(null)} />}
    </>
  );
}

function StatCard({ icon: Icon, label, value, tone }) {
  return (
    <div className="stat-card">
      <div className="stat-card-top">
        <div className={`stat-card-icon ${tone !== 'default' ? `tone-${tone}` : ''}`}>
          <Icon />
        </div>
      </div>
      <strong>{value}</strong>
      <span className="stat-label">{label}</span>
    </div>
  );
}

function SkeletonRows() {
  return (
    <div className="skeleton-rows">
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="skeleton skeleton-line" />
      ))}
    </div>
  );
}