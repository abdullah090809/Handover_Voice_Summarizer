from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.cores.database import get_db
from app.cores.security import get_current_user
from app.models.shift import Shift, compute_shift_numbers
from app.models.user import User
from app.schemas.shift import ShiftCreate, ShiftOut

router = APIRouter(prefix="/shifts", tags=["Shifts"])


@router.post("/", response_model=ShiftOut, status_code=status.HTTP_201_CREATED)
def create_shift(
    shift: ShiftCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    new_shift = Shift(worker_id=current_user.id, **shift.model_dump())
    db.add(new_shift)
    db.commit()
    db.refresh(new_shift)
    # pyrefly: ignore [bad-argument-type]
    new_shift.shift_number = compute_shift_numbers(db, {current_user.id}).get(new_shift.id)
    return new_shift


@router.get("/", response_model=list[ShiftOut])
def list_my_shifts(
    worker_id: int | None = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if worker_id is not None:
        if current_user.role != "manager":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only managers can view other workers' shifts",
            )

        target_worker = db.query(User).filter(User.id == worker_id).first()
        if not target_worker:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Worker with id {worker_id} not found",
            )

        query_id = worker_id
    else:
        query_id = current_user.id

    results = (
        db.query(Shift)
        .filter(Shift.worker_id == query_id)
        .offset(skip)
        .limit(limit)
        .all()
    )
    # pyrefly: ignore [bad-argument-type]
    numbers = compute_shift_numbers(db, {query_id})
    for shift in results:
        # pyrefly: ignore [bad-argument-type]
        shift.shift_number = numbers.get(shift.id)
    return results


@router.get("/{id}", response_model=ShiftOut)
def get_shift(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    shift = db.query(Shift).filter(Shift.id == id).first()

    if not shift:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Shift with id {id} not found",
        )

    if shift.worker_id != current_user.id and current_user.role != "manager":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to view this shift",
        )

    # pyrefly: ignore [bad-argument-type]
    shift.shift_number = compute_shift_numbers(db, {shift.worker_id}).get(shift.id)
    return shift


@router.put("/{id}", response_model=ShiftOut)
def update_shift(
    id: int,
    updated_shift: ShiftCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    shift = db.query(Shift).filter(Shift.id == id).first()

    if not shift:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Shift with id {id} not found",
        )

    if shift.worker_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to update this shift",
        )

    # Update the ORM object directly (SQLAlchemy 2.x style)
    for field, value in updated_shift.model_dump().items():
        setattr(shift, field, value)

    db.commit()
    db.refresh(shift)
    # pyrefly: ignore [bad-argument-type]
    shift.shift_number = compute_shift_numbers(db, {shift.worker_id}).get(shift.id)

    return shift


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_shift(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    shift = db.query(Shift).filter(Shift.id == id).first()

    if not shift:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Shift with id {id} not found",
        )

    if shift.worker_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to delete this shift",
        )

    try:
        db.delete(shift)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="This shift can't be deleted because it has handover notes attached to it.",
        )

    return None