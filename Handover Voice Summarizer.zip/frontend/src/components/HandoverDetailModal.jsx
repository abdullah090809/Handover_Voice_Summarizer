import React, { useState } from 'react';
import { Trash2, Download, ChevronDown, Pill, TriangleAlert, ListChecks, Smile, Clock3, FileText, UserRound } from 'lucide-react';
import Modal from './Modal.jsx';
import { UrgencyBadge, HandoverStatusBadge } from './Badge.jsx';
import { Avatar } from './States.jsx';
import { formatDateTime, formatHandoverCode } from '../lib/format.js';
import { resolveFileUrl } from '../lib/api.js';

export default function HandoverDetailModal({ note, residentName, residentCode, canDelete, onClose, onDelete }) {
  const [showTranscript, setShowTranscript] = useState(false);
  const [showTranslated, setShowTranslated] = useState(false);
  if (!note) return null;
  const s = note.summary_json || {};
  const submitterName = note.submitted_by?.name?.trim() || note.submitted_by?.username;

  function exportJson() {
    const blob = new Blob([JSON.stringify(note, null, 2)], { type: 'application/json' });
    downloadBlob(blob, `${formatHandoverCode(note.id)}.json`);
  }

  function exportText() {
    const lines = [
      `Handover Note ${formatHandoverCode(note.id)}`,
      `Resident: ${residentName || note.resident_id}${residentCode ? ` (${residentCode})` : ''}`,
      `Created: ${formatDateTime(note.created_at)}`,
      `Urgency: ${note.urgency_flag || 'n/a'}`,
      '',
      'Summary:',
      s.summary || '—',
      '',
      'Key events:',
      ...(s.key_events || []).map((e) => `- ${e}`),
      '',
      'Medications given:',
      ...(s.medications_given || []).map((e) => `- ${e}`),
      '',
      'Incidents:',
      ...(s.incidents || []).map((e) => `- ${e}`),
      '',
      'Follow-up actions:',
      ...(s.follow_up_actions || []).map((e) => `- ${e}`),
      '',
      'Mood notes:',
      s.mood_notes || '—',
      '',
      'Translated transcript:',
      s.translated_transcript || '—',
    ];
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    downloadBlob(blob, `${formatHandoverCode(note.id)}.txt`);
  }

  return (
    <Modal
      open
      onClose={onClose}
      size="lg"
      title={residentName || `Resident #${note.resident_id}`}
      subtitle={`${residentCode ? residentCode + ' · ' : ''}${formatHandoverCode(note.id)} · Shift #${note.shift_number ?? note.shift_id} · ${formatDateTime(note.created_at)}`}
      footer={
        <>
          {canDelete && (
            <button className="btn btn-danger" onClick={() => onDelete(note)} style={{ marginRight: 'auto' }}>
              <Trash2 size={15} /> Delete note
            </button>
          )}
          <div className="export-btn-row">
            <button className="btn btn-secondary btn-sm" onClick={exportText}>
              <Download size={14} /> .txt
            </button>
            <button className="btn btn-secondary btn-sm" onClick={exportJson}>
              <Download size={14} /> .json
            </button>
          </div>
          <button className="btn btn-secondary" onClick={onClose}>
            Close
          </button>
        </>
      }
    >
      <div className="handover-meta-row">
        {note.status === 'complete' ? <UrgencyBadge urgency={note.urgency_flag} /> : <HandoverStatusBadge status={note.status} />}
        {submitterName && (
          <span className="handover-submitted-by">
            <Avatar text={submitterName} size="sm" src={resolveFileUrl(note.submitted_by?.profile_photo_url)} />
            <span>
              <UserRound size={11} /> Submitted by <strong>{submitterName}</strong>
            </span>
          </span>
        )}
      </div>

      {note.status !== 'complete' && (
        <div className={note.status === 'failed' ? 'form-error-banner' : 'form-success-banner'}>
          {note.status === 'failed' ? <TriangleAlert /> : <Clock3 />}
          <span>
            {note.status === 'failed'
              ? note.error_message || 'This recording could not be processed.'
              : 'This note is still being transcribed and summarized. It will update automatically.'}
          </span>
        </div>
      )}

      {/* Raw transcript: shown whenever we have one, even on failure — a failed
          AI summary shouldn't hide a transcript that was already captured. */}
      {note.status === 'failed' && note.raw_transcript && (
        <div className="handover-read-section">
          <button
            className="collapsible-trigger"
            style={{ padding: 0 }}
            onClick={() => setShowTranscript((v) => !v)}
            aria-expanded={showTranscript}
          >
            <span className="collapsible-trigger-title">
              <FileText size={14} /> Transcript (summary generation failed)
            </span>
            <ChevronDown className={`collapsible-chevron ${showTranscript ? 'open' : ''}`} />
          </button>
          {showTranscript && <div className="handover-transcript-block">{note.raw_transcript}</div>}
        </div>
      )}

      {note.status === 'complete' && (
        <>
          <div className="handover-read-section">
            <h4>Summary</h4>
            <p className="handover-read-summary">{s.summary || 'No summary text was generated.'}</p>
          </div>

          {s.key_events?.length > 0 && (
            <div className="handover-read-section">
              <h4>Key events</h4>
              <div className="handover-read-list">
                {s.key_events.map((item, i) => (
                  <div className="handover-read-item" key={i}>
                    <span className="bullet-dot" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {s.medications_given?.length > 0 && (
            <div className="handover-read-section">
              <h4>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                  <Pill size={12} /> Medications given
                </span>
              </h4>
              <div className="handover-read-list">
                {s.medications_given.map((item, i) => (
                  <div className="handover-read-item medication" key={i}>
                    <span className="bullet-dot" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {s.incidents?.length > 0 && (
            <div className="handover-read-section">
              <h4>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'var(--urgency-high)' }}>
                  <TriangleAlert size={12} /> Incidents
                </span>
              </h4>
              <div className="handover-read-list">
                {s.incidents.map((item, i) => (
                  <div className="handover-read-item incident" key={i}>
                    <span className="bullet-dot" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {s.follow_up_actions?.length > 0 && (
            <div className="handover-read-section">
              <h4>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                  <ListChecks size={12} /> Follow-up actions
                </span>
              </h4>
              <div className="handover-read-list">
                {s.follow_up_actions.map((item, i) => (
                  <div className="handover-read-item action" key={i}>
                    <span className="bullet-dot" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {s.mood_notes && (
            <div className="handover-read-section">
              <h4>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                  <Smile size={12} /> Mood &amp; wellbeing
                </span>
              </h4>
              <p className="handover-read-summary">{s.mood_notes}</p>
            </div>
          )}

          {s.translated_transcript && (
            <div className="handover-read-section">
              <button
                className="collapsible-trigger"
                style={{ padding: 0 }}
                onClick={() => setShowTranslated((v) => !v)}
                aria-expanded={showTranslated}
              >
                <span className="collapsible-trigger-title">
                  <FileText size={14} /> Translated transcript
                </span>
                <ChevronDown className={`collapsible-chevron ${showTranslated ? 'open' : ''}`} />
              </button>
              {showTranslated && (
                <div className="handover-transcript-block">{s.translated_transcript}</div>
              )}
            </div>
          )}

          {note.raw_transcript && (
            <div className="handover-read-section">
              <button
                className="collapsible-trigger"
                style={{ padding: 0 }}
                onClick={() => setShowTranscript((v) => !v)}
                aria-expanded={showTranscript}
              >
                <span className="collapsible-trigger-title">
                  <FileText size={14} /> Raw transcript
                </span>
                <ChevronDown className={`collapsible-chevron ${showTranscript ? 'open' : ''}`} />
              </button>
              {showTranscript && <div className="handover-transcript-block">{note.raw_transcript}</div>}
            </div>
          )}
        </>
      )}
    </Modal>
  );
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}